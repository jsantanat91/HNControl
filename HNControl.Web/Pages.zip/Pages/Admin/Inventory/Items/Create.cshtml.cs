using System.ComponentModel.DataAnnotations;
using HNControl.Web.Data;
using HNControl.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace HNControl.Web.Pages.Admin.Inventory.Items;

[Authorize(Roles = AppRoles.Admin)]
public class CreateModel : PageModel
{
    private readonly ApplicationDbContext _db;
    public CreateModel(ApplicationDbContext db) => _db = db;
    public List<SelectListItem> CategoryOptions { get; set; } = new();
    public List<SelectListItem> LocationOptions { get; set; } = new();

    [BindProperty] public InputModel Input { get; set; } = new();

    public List<SelectListItem> BrandOptions { get; set; } = new();

    public class InputModel
    {
        [Required, MaxLength(160)]
        public string Name { get; set; } = "";

        [MaxLength(60)]
        public string? Sku { get; set; }

        [MaxLength(100)]
        public string? Category { get; set; }

        public Guid? BrandId { get; set; }

        [MaxLength(120)]
        public string? Model { get; set; }

        [MaxLength(200)]
        public string? Location { get; set; }

        [MaxLength(20)]
        public string Unit { get; set; } = "pz";

        public bool IsConsumable { get; set; } = true;

        [Range(0, 999999)]
        public decimal QuantityOnHand { get; set; } = 0;

        [Range(0, 999999)]
        public decimal ReorderLevel { get; set; } = 0;

        [MaxLength(2000)]
        public string? Notes { get; set; }

        public bool IsActive { get; set; } = true;
    }

    public async Task OnGetAsync()
    {
        await LoadCatalogsAsync();
    }

    private async Task LoadCatalogsAsync()
    {
        BrandOptions = await _db.InventoryBrands
            .AsNoTracking()
            .Where(b => b.IsActive)
            .OrderBy(b => b.Name)
            .Select(b => new SelectListItem(b.Name, b.Id.ToString()))
            .ToListAsync();
        BrandOptions.Insert(0, new SelectListItem("— Sin marca —", ""));

        CategoryOptions = await _db.InventoryCategories
            .AsNoTracking()
            .Where(c => c.IsActive)
            .OrderBy(c => c.Name)
            .Select(c => new SelectListItem(c.Name, c.Name))
            .ToListAsync();
        CategoryOptions.Insert(0, new SelectListItem("— Sin categoría —", ""));

        LocationOptions = await _db.InventoryLocations
            .AsNoTracking()
            .Where(l => l.IsActive)
            .OrderBy(l => l.Name)
            .Select(l => new SelectListItem(l.Name, l.Name))
            .ToListAsync();
        LocationOptions.Insert(0, new SelectListItem("— Sin ubicación —", ""));
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            await LoadCatalogsAsync();
            return Page();
        }

        _db.InventoryItems.Add(new InventoryItem
        {
            Name = Input.Name.Trim(),
            Sku = string.IsNullOrWhiteSpace(Input.Sku) ? null : Input.Sku.Trim(),
            Category = (Input.Category ?? "").Trim(),
            BrandId = Input.BrandId,
            Model = string.IsNullOrWhiteSpace(Input.Model) ? null : Input.Model.Trim(),
            Location = string.IsNullOrWhiteSpace(Input.Location) ? null : Input.Location.Trim(),
            Unit = (Input.Unit ?? "pz").Trim(),
            IsConsumable = Input.IsConsumable,
            QuantityOnHand = Input.QuantityOnHand,
            ReorderLevel = Input.ReorderLevel,
            Notes = (Input.Notes ?? "").Trim(),
            IsActive = Input.IsActive,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        });

        await _db.SaveChangesAsync();
        return RedirectToPage("./Index");
    }
}
