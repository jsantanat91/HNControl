using System.Text.Json;
using HNControl.Web.Data;
using HNControl.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace HNControl.Web.Pages.Admin.Employees;

[Authorize(Roles = AppRoles.Admin)]
public class DetailsModel : PageModel
{
    private readonly ApplicationDbContext _db;
    public DetailsModel(ApplicationDbContext db) => _db = db;

    public EmployeeProfile? Employee { get; set; }

    public record KpiVm(int CompletedOrders30d, int InReviewOrders, int ActiveProjects, int OverdueProjects, decimal WeeklyViaticTotal);
    public KpiVm Kpi { get; set; } = new(0, 0, 0, 0, 0m);

    public PerformanceReview? LastReview { get; set; }
    public string LastReviewPeriod { get; set; } = "�";

    public record PayVm(decimal Fixed80, decimal VariableMoney, decimal Total);
    public PayVm Pay { get; set; } = new(0, 0, 0);

    public string ChartLabelsJson { get; set; } = "[]";
    public string ChartValuesJson { get; set; } = "[]";

    public async Task<IActionResult> OnGetAsync(string userId)
    {
        Employee = await _db.EmployeeProfiles.FirstOrDefaultAsync(e => e.UserId == userId);
        if (Employee == null) return NotFound();

        var now = DateTime.UtcNow;
        var since30 = now.AddDays(-30);

        // �rdenes (ajusta nombres si tu entidad usa otras props)
        var completedOrders30d = await _db.ServiceOrders
            .Where(o => o.AssignedUserId == userId && o.Status == ServiceOrderStatus.Completed && o.CompletedAt != null && o.CompletedAt >= since30)
            .CountAsync();

        var inReview = await _db.ServiceOrders
            .Where(o => o.AssignedUserId == userId && o.Status == ServiceOrderStatus.InReview)
            .CountAsync();

        var activeProjects = await _db.Projects
            .Where(p => p.ResponsibleUserId == userId && p.Status == ProjectStatus.Active)
            .CountAsync();

        var overdue = await _db.Projects
            .Where(p => p.ResponsibleUserId == userId && p.Status == ProjectStatus.Active && p.EstimatedEndDate != null && p.EstimatedEndDate < DateTime.UtcNow.Date)
            .CountAsync();

        // Vi�ticos semana actual (si tu modelo difiere, cambia el query)
        var weekStart = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek + (int)DayOfWeek.Monday);
        var viatic = await _db.ViaticWeeks
            .Where(w => w.UserId == userId && w.WeekStart == weekStart)
            .Select(w => (decimal?)w.TotalAmount)
            .FirstOrDefaultAsync() ?? 0m;

        Kpi = new KpiVm(completedOrders30d, inReview, activeProjects, overdue, viatic);

        LastReview = await _db.PerformanceReviews
            .Where(r => r.UserId == userId)
            .OrderByDescending(r => r.PeriodStart)
            .FirstOrDefaultAsync();

        if (LastReview != null)
        {
            LastReviewPeriod = $"{LastReview.PeriodStart:yyyy-MM-dd} a {LastReview.PeriodEnd:yyyy-MM-dd}";
            var base80 = Employee.SalaryBase * 0.80m;
            var max20 = Employee.SalaryBase * 0.20m;
            var varMoney = max20 * LastReview.VariablePercent;
            Pay = new PayVm(base80, varMoney, base80 + varMoney);
        }

        var last12 = await _db.PerformanceReviews
            .Where(r => r.UserId == userId)
            .OrderBy(r => r.PeriodStart)
            .Take(12)
            .ToListAsync();

        ChartLabelsJson = JsonSerializer.Serialize(last12.Select(r => r.PeriodStart.ToString("MM-dd")).ToList());
        ChartValuesJson = JsonSerializer.Serialize(last12.Select(r => (double)r.VariablePercent).ToList());

        return Page();
    }
}
