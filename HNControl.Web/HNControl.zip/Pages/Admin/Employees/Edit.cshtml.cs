using System.ComponentModel.DataAnnotations;
using HNControl.Web.Data;
using HNControl.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace HNControl.Web.Pages.Admin.Employees;

[Authorize(Roles = AppRoles.Admin)]
public class EditModel : PageModel
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;

    public EditModel(ApplicationDbContext db, UserManager<ApplicationUser> userManager)
    {
        _db = db;
        _userManager = userManager;
    }

    public EmployeeProfile? Employee { get; set; }
    public string? Info { get; set; }

    [BindProperty] public InputModel Input { get; set; } = new();

    public class InputModel
    {
        [Required] public string UserId { get; set; } = "";

        [Required, MaxLength(120)] public string FullName { get; set; } = "";
        [MaxLength(80)] public string Position { get; set; } = "";

        [MaxLength(40)] public string? Phone { get; set; }
        [MaxLength(20)] public string? Sex { get; set; }
        [MaxLength(20)] public string? Nss { get; set; }

        [MaxLength(18)] public string? Curp { get; set; }
        [MaxLength(400)] public string? Address { get; set; }

        [DataType(DataType.Date)] public DateTime? BirthDate { get; set; }
        [DataType(DataType.Date)] public DateTime? HireDate { get; set; }

        [Required, EmailAddress] public string Email { get; set; } = "";
        [Range(0, 99999999)] public decimal SalaryBase { get; set; }
    }

    public async Task<IActionResult> OnGetAsync(string userId)
    {
        Employee = await _db.EmployeeProfiles.FirstOrDefaultAsync(e => e.UserId == userId);
        if (Employee == null) return NotFound();

        var user = await _userManager.FindByIdAsync(userId);
        var email = user?.Email ?? Employee.Email ?? "";

        Input = new InputModel
        {
            UserId = Employee.UserId,
            FullName = Employee.FullName,
            Position = Employee.Position,
            Phone = Employee.Phone,
            Sex = Employee.Sex,
            Nss = Employee.Nss,
            Curp = Employee.Curp,
            Address = Employee.Address,
            BirthDate = Employee.BirthDate,
            HireDate = Employee.HireDate,
            SalaryBase = Employee.SalaryBase,
            Email = email
        };

        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid) return Page();

        Employee = await _db.EmployeeProfiles.FirstOrDefaultAsync(e => e.UserId == Input.UserId);
        if (Employee == null) return NotFound();

        // Update profile
        Employee.FullName = Input.FullName.Trim();
        Employee.Position = (Input.Position ?? "").Trim();
        Employee.Phone = (Input.Phone ?? "").Trim();
        Employee.Sex = (Input.Sex ?? "").Trim();
        Employee.Nss = (Input.Nss ?? "").Trim();
        Employee.Curp = (Input.Curp ?? "").Trim().ToUpperInvariant();
        Employee.Address = (Input.Address ?? "").Trim();
        Employee.BirthDate = Input.BirthDate;
        Employee.HireDate = Input.HireDate;
        Employee.SalaryBase = Input.SalaryBase;
        Employee.Email = Input.Email.Trim();
        Employee.UpdatedAt = DateTime.UtcNow;

        // Update Identity email/username
        var user = await _userManager.FindByIdAsync(Input.UserId);
        if (user != null)
        {
            var newEmail = Input.Email.Trim();

            if (!string.Equals(user.Email, newEmail, StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(user.UserName, newEmail, StringComparison.OrdinalIgnoreCase))
            {
                user.Email = newEmail;
                user.UserName = newEmail;
                await _userManager.UpdateAsync(user);
            }
        }

        await _db.SaveChangesAsync();

        return RedirectToPage("./Details", new { userId = Input.UserId });
    }
}
